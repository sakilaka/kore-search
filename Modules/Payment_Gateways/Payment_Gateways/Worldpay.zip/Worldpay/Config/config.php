<?php

return [
    'name' => __('Worldpay'),
    'ENABLE' => env('WORLDPAY_ENABLE'),
    'WORLDPAY_CLIENT_KEY' => env('WORLDPAY_CLIENT_KEY'),
    'WORLDPAY_SECRET_KEY' => env('WORLDPAY_SECRET_KEY')
];
