<?php

return [
    'name' => 'Smanager'
];
