<?php

return [
    'name' => 'SquarePay',
    'ENABLE' => env('SQUARE_PAY_ENABLE'),
    'SQUARE_PAY_LOCATION_ID' => env('SQUARE_PAY_LOCATION_ID'),
    'SQUARE_ACCESS_TOKEN' => env('SQUARE_ACCESS_TOKEN'),
    'SQUARE_APPLICATION_ID' => env('SQUARE_APPLICATION_ID')
];
