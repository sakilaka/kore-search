<!-- This will append Onepay payment tab content on admin payment settings page. -->
<!-- Onepay payment tab content start -->
<a class="nav-link" data-toggle="pill" href="#v-pills-onepay" role="tab" aria-selected="false"> <img src="{{ url('images/payment/api_setting/onepay.png') }}" class="img-fluid" width="70px" height="70px" alt="">
</a>

<!-- Onepay payment tab content end -->