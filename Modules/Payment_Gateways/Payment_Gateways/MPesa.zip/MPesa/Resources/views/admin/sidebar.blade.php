<!-- This will append MPesa payment menu on admin sidebar page. -->
<!-- MPesa payment menu start -->
<li class="{{ Nav::isRoute('mpesa.setting') }}"><a href="{{route('mpesa.setting')}}"><span>{{ __('MPESA Settings') }}</span></a></li>
<!-- MPesa payment menu end -->